package can.cigo.zoomgibi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoomgibiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoomgibiApplication.class, args);
	}

}
